#include <stdio.h>

int main()
{
    printf("char = %lu byte \n"); sizeof(char);
    printf("int = %lu byte \n"); sizeof(int);
    printf("float = %lu byte \n"); sizeof(float);
    printf("double = %lu byte \n"); sizeof(double);

    return 0;
}
